public class Prob5_RadixSortLex {
    public static void radixSort(String[] arr) {
        final int RADIX = 256; // ASCII range
        int maxLength = maxLength(arr);

        // Sort from the last character to the first
        for (int i = maxLength - 1; i >= 0; i--) {
            countingSort(arr, i, RADIX);
        }
    }

    private static void countingSort(String[] arr, int index, int radix) {
        int[] count = new int[radix];
        String[] temp = new String[arr.length];

        // Count frequencies of characters at index position
        for (String str : arr) {
            int charIndex = index < str.length() ? str.charAt(index) : 0;
            count[charIndex]++;
        }

        // Convert count array to positions
        for (int i = 1; i < radix; i++) {
            count[i] += count[i - 1];
        }

        // Build the temporary array in lexicographic order
        for (int i = arr.length - 1; i >= 0; i--) {
            int charIndex = index < arr[i].length() ? arr[i].charAt(index) : 0;
            temp[count[charIndex] - 1] = arr[i];
            count[charIndex]--;
        }

        // Copy temp back to arr
        System.arraycopy(temp, 0, arr, 0, arr.length);
    }

    private static int maxLength(String[] arr) {
        int max = 0;
        for (String str : arr) {
            max = Math.max(max, str.length());
        }
        return max;
    }

    public static void main(String[] args) {
        String[] arr = {"gojo", "google", "jogo", "bill", "pup", "cipher", "watchmen", "knight", "it", "stand", "sandman", "hydra", "surtr"};

        // Adding support for uppercase letters by converting them to lowercase
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i].toLowerCase();
        }

        radixSort(arr);

        // Print the sorted array
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i != arr.length - 1) {
                System.out.print(", ");
            }
        }
    }
}
