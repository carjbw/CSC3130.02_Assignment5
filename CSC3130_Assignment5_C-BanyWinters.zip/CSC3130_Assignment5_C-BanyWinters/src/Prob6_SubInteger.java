import java.util.HashSet;
import java.util.Set;

public class Prob6_SubInteger {
    public static String isSubset(int[] S, int[] T) {
        Set<Integer> setT = new HashSet<>();

        // Add all elements of T to the hash set
        for (int num : T) {
            setT.add(num);
        }

        // Check if each element of S is in setT
        for (int num : S) {
            if (!setT.contains(num)) {
                return "No";
            }
        }

        return "Yes";
    }

    public static void main(String[] args) {
        int[] S1 = {32, 3};
        int[] T1 = {1, 2, 3, 52, 32, 54};
        System.out.println(isSubset(S1, T1)); // Output: Yes

        int[] S2 = {89, 32, 54, 32, 3};
        int[] T2 = {54, 32, 99};
        System.out.println(isSubset(S2, T2)); // Output: No

        int[] S3 = {0, 67};
        int[] T3 = {100, 5, 66, 2, 32, 90};
        System.out.println(isSubset(S3, T3)); // Output: No

        int[] S4 = {};
        int[] T4 = {54, 32, 99};
        System.out.println(isSubset(S4, T4)); // Output: Yes
    }
}
