import java.util.Arrays;

public class ProbEC_SumTarget {
    public static int[] sumTarget(int[] A, int K) {
        if (A == null || A.length == 0) {
            return new int[]{-1, -1};
        }

        int n = A.length;
        int start = 0, end = 0;
        int sum = A[0];

        while (start < n && end < n) {
            if (sum == K) {
                return new int[]{start, end};
            } else if (sum < K) {
                end++;
                if (end < n) {
                    sum += A[end];
                }
            } else {
                sum -= A[start];
                start++;
            }
        }

        return new int[]{-1, -1};
    }

    public static void main(String[] args) {
        int[] A1 = {1, 2, 3, 7, 5};
        int K1 = 12;
        System.out.println(Arrays.toString(sumTarget(A1, K1))); // Output: [1, 3] or [3, 4]

        int[] A2 = {1, 2, 3, 7, 5};
        int K2 = 5;
        System.out.println(Arrays.toString(sumTarget(A2, K2))); // Output: [1, 2] or [4, 4]

        int[] A3 = {1, 2, 3, 7, 5};
        int K3 = 7;
        System.out.println(Arrays.toString(sumTarget(A3, K3))); // Output: [3, 3]

        int[] A4 = {1, 2, 3, 7, 5};
        int K4 = 11;
        System.out.println(Arrays.toString(sumTarget(A4, K4))); // Output: [-1, -1]
    }
}
